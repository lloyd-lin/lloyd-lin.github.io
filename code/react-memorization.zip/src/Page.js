import React, { Component } from "react";
import classnames from "classnames";
import TextInput from "./TextInput";
// import PureTextInput from "./PureTextInput";
import memorize from "memoize-one";

export default class Page extends Component {
  state = {
    active: false,
    text: "default"
  };

  // filter(dataArr) {
  //   let count = 0;
  //   dataArr.forEach((ele) => {
  //     if (ele%7 === 0) {
  //       count ++;
  //     }
  //   });
  //   return count;
  // }
  // sample memorize
  filter = memorize(dataArr => {
    let count = 0;
    dataArr.forEach(ele => {
      if (ele % 7 === 0) {
        count++;
      }
    });
    return count;
  });
  componentDidMount() {
    console.log("mounted");
  }
  // handleChange = event => {
  //   this.setState({ text: event.target.value });
  // };

  udpateText() {
    this.setState({
      text: `default:avtive is ${this.state.active}`,
      id: new Date().getMilliseconds()
    });
  }

  highlightBtn() {
    this.setState({
      active: !this.state.active
    });
  }

  //sample 2
  // shouldComponentUpdate(nextProps, nextState) {
  //   if (nextState.text !== this.state.text) {
  //     return true;
  //   }
  //   return false;
  // }

  render() {
    console.log("render page");
    const { active } = this.state;
    const clazz = classnames("btn", active ? "active" : "inActive");
    //origin
    // return (
    //   <>
    //     <TextInput text={this.state.text} />
    //     <div className="btn active" onClick={this.udpateText.bind(this)}>
    //       更新text
    //     </div>
    //     <div className={clazz} onClick={this.highlightBtn.bind(this)}>
    //       更新其他属性
    //     </div>
    //   </>
    // );

    // sample 4
    // return (
    //   <>
    //     <PureTextInput
    //       text={this.state.text}
    //       handleChange={this.handleChange.bind(this)}
    //     />
    //     <div className="btn active" onClick={this.udpateText.bind(this)}>
    //       更新text
    //     </div>
    //     <div className={clazz} onClick={this.highlightBtn.bind(this)}>
    //       更新其他属性
    //     </div>
    //   </>
    // );

    // sample5
    const calResult = this.filter(this.props.data);
    return (
      <>
        <TextInput text={this.state.text} key={this.state.id} />
        <div className="btn active" onClick={this.udpateText.bind(this)}>
          更新text
        </div>
        <div className={clazz} onClick={this.highlightBtn.bind(this)}>
          更新其他属性
        </div>
        <div>可以被7整除的数字数量为{calResult}</div>
      </>
    );
  }
}
