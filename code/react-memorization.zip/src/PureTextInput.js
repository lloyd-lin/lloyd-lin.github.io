import React, { Component, PureComponent } from "react";

export default class PureTextInput extends PureComponent {
  render() {
    return <input onChange={this.props.handleChange} value={this.props.text} />;
  }
}
