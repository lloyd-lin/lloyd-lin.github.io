import React, { Component } from "react";
import classnames from "classnames";

export default class TextInput extends Component {
  state = {
    text: this.props.text
  };

  render() {
    console.log("render compoent");
    return <input onChange={this.handleChange.bind(this)} value={this.state.text} />;
  }

  handleChange = event => {
    console.log('handle')
    this.setState({ text: event.target.value });
  };

  // This lifecycle will be re-run any time the component is rendered,
  // Even if props.email has not changed.
  // For this reason, it should not update state in the way shown below!
  // componentWillReceiveProps(nextProps) {
  // This will erase any local state updates!
  // Do not do this!
  // sample1
  // 问题 父组件render将会无脑导致更新
  // componentWillReceiveProps(nextProps) {
  //   console.log('reveice')
  //   this.setState({ text:nextProps.text });
  // }

  // sample3 改进版
  // componentWillReceiveProps(nextProps) {
  //   if (nextProps.text !== this.props.text) {
  //     this.setState({ text: nextProps.text });
  //   }
  // }

  // static getDerivedStateFromProps(props, state) {
  //   if (props.text !== state.prevPropsText) {
  //     return {
  //       prevPropsText: props.text,
  //       text: props.text
  //     };
  //   }
  //   return null;
  // }
  // shouldComponentUpdate(nextProps, nextState) {
  //   console.log("this.props", this.props.text);
  //   console.log("nextProps", nextProps.text);
  //   console.log("this.state", this.state.text);
  //   console.log("nextState", nextState.text);

  //   // sample 2 控制更新时机
  //   // if (nextProps.text !== this.props.text) {
  //   //   return true;
  //   // } else if (nextState.text !== this.state.text) {
  //   //   return true;
  //   // }
  //   // return false;

  //   return true;
  // }
}
