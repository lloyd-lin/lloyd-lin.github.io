import React from "react";
import ReactDOM from "react-dom";
import Page from "./Page";

import "./styles.css";

function App() {
  const arr = [];
  for (let i = 0; i < 100000000; i++) {
    arr.push(i);
  }
  return <Page data={arr} />;
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
